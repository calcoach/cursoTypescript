main (void){
int i;
int j;
char c;
char cadena
float z;
z=14.9e-8;
z=12.9;
cadena="Hola";
scanf ("%d",i);
i=i*2;
printf ("El doble es %d",i);
}
