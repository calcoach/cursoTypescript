#!/bin/bash
#this script compile and create the analyzer and it's dependecies

#creates the needed output files
touch salida.txt
touch saliday.txt

echo "compilando analizador sintactico "
yacc -d bin/a_sintactico.y
mv ./y.tab.c ./bin/y.tab.c
mv ./y.tab.h ./bin/y.tab.h

echo "compilando analizador lexico "
flex ./bin/a_lexico.l
mv lex.yy.c ./bin/lex.yy.c

echo "compilando ejecutable "
gcc ./bin/y.tab.c ./bin/lex.yy.c -o analizador.out  

echo "COMPILACION EXITOSA!"

echo "ejecutando el ejecutable"
./analizador.out
