# Compiladores - Laboratorio 2

**Hecho por:**

- Jairo Jesus Gonzalez Hernandez
- Maria Alejandra Zapata Montaño
- Kang Cheng Lei Lei
- Ivan Esteban Perez De la Ossa


**Ejecucion:**
    
    desde el directorio raiz ejecutar:
    sh run.sh
